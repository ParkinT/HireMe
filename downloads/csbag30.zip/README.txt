CSBAG (Customizable "Slithering Button" Application Generator) lets you create your own joke application in which the desired choice button "slithers" away from the user.
The key to C.S.B.A.G. is in the fact that you can customize the program's buttons and text by editing its .ini file (in the Windows folder) with any text editor.
This fun, free program requires no additional .dll or runtime files. 

Version Number
3.0

Compressed Size
196,608 bytes 

*Defaults
The first button will always appear.  If it is disabled in the Configuration program or not named in the INI file, it will contain the test "No" by default.
The EXIT button also cannot be eliminated. It's default value is "Quit".
Each button will show the first character as an accelerator key (underlined to be activated with the ALT-key combination).  If the user tries to 'outsmart' your application by using the accelerator key combination, that button disappears completely!

*Interactive Editor
The Interactive Configuration program is built-in to CSBAG.
You can use it both to create an INI fresh or to modify one already existing.
The program looks first in the WINDOWS [WINNT] directory for the INI.  If it is not found, it will search the current directory.
The procedure for using this tool is;
1) copy CSBAG.EXE to the application name you wish to use for your joke
2) from the Start | Run (or create a shortcut) use the command {appname} /Config
3) you can use the mouse or Tab from field to field.  Just fill in the form exactly as you want it to appear in your final application.
Press the TITLE button to program the text that appears on the Title bar of the  window.  (note: this Title does NOT affect the name of your final program.  That requires renaming the executable)
Press SAVE when you are finished.  As a confirmation the name of the INI file created will be displayed.

*Tips and Tricks
When working on the layout of your Application, you may want to be particular about the positioning of text on the line.
If text is to be displayed other than at the left margin, it must be enclosed in double quotes.
As an example;
"                   This text will appear in the center"
                    This text will begin at the left margin
Each line is an individual control and must have its own quotes.

========================================================================================
SIMPLE TUTORIAL
C.S.B.A.G. does not require any programming skills to configure.  But many people are not comfortable editing INI files.  If you are having difficulty understanding the steps described above, follow this simple tutorial.

CSBAG, as it comes to you, is the base application.  As described it is a JOKE APPLICATION GENERATOR.  The joke application you generate can have any name you choose.  It will be a copy of CSBAG.exe under that new name.  In Windows, if you select the CSBAG.exe and click the right button on your mouse (right-click) a menu appears.  Choose COPY from that menu.  Then go to an area where your mouse is NOT on a file and right-click.  Choose PASTE from the menu.  This will create a copy of CSBAG.exe named "Copy of CSBAG.exe".
Now, if you right-click again on that new file and choose RENAME from the menu you can make it whatever name you wish.  For the sake of example let's use the name LOTTERY.exe
(The alternative to all this is to create a Shortcut to CSBAG.exe and make the COMMAND LINE field read /Config at the end of the CSBAG.exe.  If you do not know how to create a shortcut, check your Windows documentation or find someone you know who is very proficient with computers to show you the first time)
Now that we have LOTTERY.exe we need to do one more thing.  Find the CSBAG.ini file (it will most likely be in the \Windows folder; but it can also exist in the same folder as the CSBAG.exe) and RENAME it to LOTTERY.ini
If you now double-click on LOTTERY.ini it will open in an editor (proably Notepad or Wordpad).
If you look carefully at the contents of this file it is pretty easy to understand what each parameter does and how to change it.  I learn best by example, so here is one.
Change the lines as required to look like the following;

[Application]
Title=Web Lottery Results
Line1="                                     C O N G R A T U L A T I O N S ! ! ! !
Line2=You are a WINNER!!!
Line3=
Line4=The Web Lottery is a random chance drawing to win $1,000,000 and 
Line5=                               YOU HAVE DOWNLOADED THE WINNING ENTRY!
Line6=Simply click below to choose your method of payment (or decline the money)
Line7=Your response will be sent electronically to our registration center.

[Buttons]
Exit=No Thanks
First=All now
Second=$100,000/year
Third=$10,000/year

[Copyright]
Notice=(c)1997,98,99 Thom Parkin 

[Notes]
**This was created by [your name here] for your entertainment

Now, simply save your changes and you have a working CSBAG application to send to a friend (victim).  Using a program like PKZIP, you can combine these two files (LOTTERY.exe and LOTTERY.ini) into one file.  Do not send CSBAG.exe or you will give away the secret!


========================================================================================
ADVANCED FEATURES
The changes to C.S.B.A.G. are significant.  And their implications are not immediately obvious. Likewise they are difficult to explain in a few simple sentences.  I suggest that after reading this section you run the TUTORIAL as described in the next section.

First, CSBAG has always relied on the name of the EXEcutable as a key to the INI file it uses.  Now, you can supply an INI filename on the command line and CSBAG will read from it.  This alone does not seem too significant.  But coupled with the next feature, it unleashes the true power of these changes.
That is, in the INI file that CSBAG uses has an additional parameter that specifies any executable program to run when CSBAG closes.  This can even be the (renamed) CSBAG executable with a command line parameter specifying a different INI file.  Get the picture now?
Or, you can execute a BATCH file that deletes the CSBSAG executable.  In that way, your joke will "cover its tracks" after it is executed.  The possibilities are endless!

ADVANCED TUTORIAL
To see an example of these new features, which makes them easier to understand, simply rename (or copy) the CSBAG.exe to example.exe and run it.  The INI file [example.ini] will begin the process.


DISCLAIMER:  These new features that are listed as ADVANCED are only for those sophisticated users who are familiar with Windows operation and the structure and editing of INI files.  Although I will gladly assist anyone in their use and enjoyment of this program, I will not provide individual support for questions relating to anything that has been described in this document.

Suggestions/Comments welcome
ThomWare@xoommail.com
